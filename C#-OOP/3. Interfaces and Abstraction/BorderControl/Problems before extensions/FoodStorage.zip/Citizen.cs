﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    class Citizen : IIdentifiable, IBirthable, IBuyer
    {
        public Citizen(string name, int number, string identityNumber, string birthDate)
        {
            Name = name;
            Age = number;
            IdentityNumber = identityNumber;
            BirthDate = birthDate;
            Food = 0;
        }

        public string Name { get; set; }
        public int Age { get; set; }
        public string IdentityNumber { get; set ; }
        public string BirthDate { get ; set ; }
        public int Food { get; set; }

        public void BuyFood()
        {
            Food += 10;
        }
    }
}
