﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    class Citizen : IIdentifiable, IBirthable
    {
        public Citizen(string name, int number, string identityNumber, string birthDate)
        {
            Name = name;
            Number = number;
            IdentityNumber = identityNumber;
            BirthDate = birthDate;
        }

        public string Name { get; set; }
        public int Number { get; set; }
        public string IdentityNumber { get; set ; }
        public string BirthDate { get ; set ; }
    }
}
