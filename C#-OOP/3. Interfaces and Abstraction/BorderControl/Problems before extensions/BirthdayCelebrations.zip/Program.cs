﻿using System;
using System.Collections.Generic;

namespace BorderControl
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            //List<IIdentifiable> wantToPass = new List<IIdentifiable>();
            List<IBirthable> citizenOrPet = new List<IBirthable>();

            while (input != "End")
            {
                string[] commandInput = input.Split(" ");

                string type = commandInput[0];

                if (type == "Citizen")
                {
                    string name = commandInput[1];
                    int age = int.Parse(commandInput[2]);
                    string identityNumber = commandInput[3];
                    string birthdate = commandInput[4];

                    Citizen citizen = new Citizen(name, age, identityNumber, birthdate);

                    citizenOrPet.Add(citizen);
                }

                else if (type == "Robot")
                {
                    string model = commandInput[1];
                    string identityNumber = commandInput[2];

                    Robot robot = new Robot(model, identityNumber);

                }

                else if (type == "Pet")
                {
                    string name = commandInput[1];
                    string birthdate = commandInput[2];

                    Pet pet = new Pet(name, birthdate);

                    citizenOrPet.Add(pet);
                }


                input = Console.ReadLine();
            }

            int number = int.Parse(Console.ReadLine());

            foreach (var type in citizenOrPet)
            {
                if (type.BirthDate.EndsWith($"{number}"))
                {
                    Console.WriteLine($"{type.BirthDate}");
                }
            }
        }
    }
}
