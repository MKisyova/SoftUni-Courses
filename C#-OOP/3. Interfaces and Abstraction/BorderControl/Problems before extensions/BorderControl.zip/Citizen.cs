﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    class Citizen : IIdentifiable
    {
        public Citizen(string name, int number, string identityNumber)
        {
            Name = name;
            Number = number;
            IdentityNumber = identityNumber;
        }

        public string Name { get; set; }
        public int Number { get; set; }
        public string IdentityNumber { get; set ; }
    }
}
