﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    class Robot : IIdentifiable
    {
        public Robot(string model, string identityNumber)
        {
            Model = model;
            IdentityNumber = identityNumber;
        }

        public string Model { get; set; }
        public string IdentityNumber { get ; set; }
    }
}
