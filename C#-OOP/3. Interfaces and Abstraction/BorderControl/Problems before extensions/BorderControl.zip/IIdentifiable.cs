﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    interface IIdentifiable
    {
        public string IdentityNumber { get; set; }
    }
}
