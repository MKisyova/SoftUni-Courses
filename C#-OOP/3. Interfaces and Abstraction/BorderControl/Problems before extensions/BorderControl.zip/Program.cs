﻿using System;
using System.Collections.Generic;

namespace BorderControl
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            List<IIdentifiable> wantToPass = new List<IIdentifiable>();

            while (input != "End")
            {
                string[] commandInput = input.Split(" ");

                if (commandInput.Length == 3)
                {
                    string name = commandInput[0];
                    int age = int.Parse(commandInput[1]);
                    string identityNumber = commandInput[2];

                    Citizen citizen = new Citizen(name, age, identityNumber);
                    wantToPass.Add(citizen);
                }

                else if (commandInput.Length == 2)
                {
                    string model = commandInput[0];
                    string identityNumber = commandInput[1];

                    Robot robot = new Robot(model, identityNumber);
                    wantToPass.Add(robot);
                }


                input = Console.ReadLine();
            }

            int number = int.Parse(Console.ReadLine());

            foreach (var passenger in wantToPass)
            {
                if (passenger.IdentityNumber.EndsWith($"{number}"))
                {
                    Console.WriteLine($"{passenger.IdentityNumber}");
                }
            }
        }
    }
}
